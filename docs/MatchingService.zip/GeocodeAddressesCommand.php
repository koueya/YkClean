<?php

namespace App\Command;

use App\Entity\User\Prestataire;
use App\Entity\Service\ServiceRequest;
use App\Repository\User\PrestataireRepository;
use App\Repository\Service\ServiceRequestRepository;
use App\Service\Geocoding\GeocodingService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\Console\Helper\ProgressBar;

#[AsCommand(
    name: 'app:geocode:addresses',
    description: 'Géocode les adresses des prestataires et service requests sans coordonnées GPS',
)]
class GeocodeAddressesCommand extends Command
{
    public function __construct(
        private EntityManagerInterface $entityManager,
        private PrestataireRepository $prestataireRepository,
        private ServiceRequestRepository $serviceRequestRepository,
        private GeocodingService $geocodingService
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('type', InputArgument::OPTIONAL, 'Type à géocoder (prestataire, service_request, all)', 'all')
            ->addOption('force', 'f', InputOption::VALUE_NONE, 'Forcer le géocodage même si déjà fait')
            ->addOption('limit', 'l', InputOption::VALUE_REQUIRED, 'Nombre maximum d\'adresses à géocoder', null)
            ->addOption('provider', 'p', InputOption::VALUE_REQUIRED, 'Provider de géocodage (google, nominatim)', null)
            ->addOption('dry-run', null, InputOption::VALUE_NONE, 'Simuler sans sauvegarder')
            ->setHelp(<<<'HELP'
Cette commande géocode les adresses qui n'ont pas encore de coordonnées GPS.

Exemples d'utilisation :

    # Géocoder toutes les adresses manquantes
    php bin/console app:geocode:addresses

    # Géocoder uniquement les prestataires
    php bin/console app:geocode:addresses prestataire

    # Forcer le géocodage de toutes les adresses
    php bin/console app:geocode:addresses --force

    # Utiliser un provider spécifique
    php bin/console app:geocode:addresses --provider=google

    # Limiter le nombre d'adresses
    php bin/console app:geocode:addresses --limit=100

    # Mode dry-run
    php bin/console app:geocode:addresses --dry-run
HELP
            );
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        
        $type = $input->getArgument('type');
        $force = $input->getOption('force');
        $limit = $input->getOption('limit') ? (int) $input->getOption('limit') : null;
        $provider = $input->getOption('provider');
        $dryRun = $input->getOption('dry-run');

        $io->title('Géocodage des adresses');

        if ($dryRun) {
            $io->warning('Mode DRY-RUN activé - Aucune modification ne sera sauvegardée');
        }

        $stats = [
            'prestataires' => ['total' => 0, 'success' => 0, 'failed' => 0, 'skipped' => 0],
            'service_requests' => ['total' => 0, 'success' => 0, 'failed' => 0, 'skipped' => 0],
        ];

        // Géocoder les prestataires
        if ($type === 'all' || $type === 'prestataire') {
            $io->section('Géocodage des prestataires');
            $stats['prestataires'] = $this->geocodePrestataires($io, $force, $limit, $provider, $dryRun);
        }

        // Géocoder les service requests
        if ($type === 'all' || $type === 'service_request') {
            $io->section('Géocodage des demandes de service');
            $stats['service_requests'] = $this->geocodeServiceRequests($io, $force, $limit, $provider, $dryRun);
        }

        // Afficher les statistiques
        $io->section('Résumé');
        
        if ($type === 'all' || $type === 'prestataire') {
            $io->text([
                '<info>Prestataires:</info>',
                sprintf('  Total traité: %d', $stats['prestataires']['total']),
                sprintf('  <fg=green>Succès: %d</>', $stats['prestataires']['success']),
                sprintf('  <fg=red>Échecs: %d</>', $stats['prestataires']['failed']),
                sprintf('  <fg=yellow>Ignorés: %d</>', $stats['prestataires']['skipped']),
            ]);
        }

        if ($type === 'all' || $type === 'service_request') {
            $io->text([
                '<info>Demandes de service:</info>',
                sprintf('  Total traité: %d', $stats['service_requests']['total']),
                sprintf('  <fg=green>Succès: %d</>', $stats['service_requests']['success']),
                sprintf('  <fg=red>Échecs: %d</>', $stats['service_requests']['failed']),
                sprintf('  <fg=yellow>Ignorés: %d</>', $stats['service_requests']['skipped']),
            ]);
        }

        $totalSuccess = $stats['prestataires']['success'] + $stats['service_requests']['success'];
        $totalFailed = $stats['prestataires']['failed'] + $stats['service_requests']['failed'];

        if ($totalFailed > 0) {
            $io->warning(sprintf('%d adresse(s) n\'ont pas pu être géocodées', $totalFailed));
        }

        if ($totalSuccess > 0) {
            $io->success(sprintf('%d adresse(s) géocodée(s) avec succès', $totalSuccess));
        } else {
            $io->info('Aucune nouvelle adresse à géocoder');
        }

        return Command::SUCCESS;
    }

    /**
     * Géocode les prestataires
     */
    private function geocodePrestataires(
        SymfonyStyle $io,
        bool $force,
        ?int $limit,
        ?string $provider,
        bool $dryRun
    ): array {
        $qb = $this->prestataireRepository->createQueryBuilder('p')
            ->where('p.address IS NOT NULL')
            ->andWhere('p.isActive = :active')
            ->setParameter('active', true);

        if (!$force) {
            $qb->andWhere('p.latitude IS NULL OR p.longitude IS NULL');
        }

        if ($limit) {
            $qb->setMaxResults($limit);
        }

        $prestataires = $qb->getQuery()->getResult();

        $stats = [
            'total' => count($prestataires),
            'success' => 0,
            'failed' => 0,
            'skipped' => 0,
        ];

        if (empty($prestataires)) {
            $io->info('Aucun prestataire à géocoder');
            return $stats;
        }

        $progressBar = new ProgressBar($io, count($prestataires));
        $progressBar->start();

        $batchSize = 20;
        $i = 0;

        foreach ($prestataires as $prestataire) {
            $progressBar->advance();

            // Vérifier si l'adresse est complète
            if (empty($prestataire->getAddress())) {
                $stats['skipped']++;
                continue;
            }

            try {
                $result = $this->geocodingService->geocode(
                    $prestataire->getAddress(),
                    $prestataire->getPostalCode(),
                    $prestataire->getCity(),
                    $provider
                );

                if ($result) {
                    if (!$dryRun) {
                        $prestataire->setLatitude($result['latitude']);
                        $prestataire->setLongitude($result['longitude']);
                        $prestataire->setGeocodedAt(new \DateTime());

                        $i++;
                        if ($i % $batchSize === 0) {
                            $this->entityManager->flush();
                            $this->entityManager->clear(Prestataire::class);
                        }
                    }

                    $stats['success']++;
                } else {
                    $stats['failed']++;
                    $io->error(sprintf(
                        'Échec géocodage prestataire #%d: %s',
                        $prestataire->getId(),
                        $prestataire->getAddress()
                    ));
                }

            } catch (\Exception $e) {
                $stats['failed']++;
                $io->error(sprintf(
                    'Erreur prestataire #%d: %s',
                    $prestataire->getId(),
                    $e->getMessage()
                ));
            }
        }

        if (!$dryRun) {
            $this->entityManager->flush();
        }

        $progressBar->finish();
        $io->newLine(2);

        return $stats;
    }

    /**
     * Géocode les service requests
     */
    private function geocodeServiceRequests(
        SymfonyStyle $io,
        bool $force,
        ?int $limit,
        ?string $provider,
        bool $dryRun
    ): array {
        $qb = $this->serviceRequestRepository->createQueryBuilder('sr')
            ->where('sr.address IS NOT NULL')
            ->andWhere('sr.status IN (:statuses)')
            ->setParameter('statuses', ['open', 'quoting', 'in_progress']);

        if (!$force) {
            $qb->andWhere('sr.latitude IS NULL OR sr.longitude IS NULL');
        }

        if ($limit) {
            $qb->setMaxResults($limit);
        }

        $serviceRequests = $qb->getQuery()->getResult();

        $stats = [
            'total' => count($serviceRequests),
            'success' => 0,
            'failed' => 0,
            'skipped' => 0,
        ];

        if (empty($serviceRequests)) {
            $io->info('Aucune demande de service à géocoder');
            return $stats;
        }

        $progressBar = new ProgressBar($io, count($serviceRequests));
        $progressBar->start();

        $batchSize = 20;
        $i = 0;

        foreach ($serviceRequests as $serviceRequest) {
            $progressBar->advance();

            if (empty($serviceRequest->getAddress())) {
                $stats['skipped']++;
                continue;
            }

            try {
                $result = $this->geocodingService->geocode(
                    $serviceRequest->getAddress(),
                    $serviceRequest->getPostalCode(),
                    $serviceRequest->getCity(),
                    $provider
                );

                if ($result) {
                    if (!$dryRun) {
                        $serviceRequest->setLatitude($result['latitude']);
                        $serviceRequest->setLongitude($result['longitude']);
                        $serviceRequest->setGeocodedAt(new \DateTime());

                        $i++;
                        if ($i % $batchSize === 0) {
                            $this->entityManager->flush();
                            $this->entityManager->clear(ServiceRequest::class);
                        }
                    }

                    $stats['success']++;
                } else {
                    $stats['failed']++;
                    $io->error(sprintf(
                        'Échec géocodage service request #%d: %s',
                        $serviceRequest->getId(),
                        $serviceRequest->getAddress()
                    ));
                }

            } catch (\Exception $e) {
                $stats['failed']++;
                $io->error(sprintf(
                    'Erreur service request #%d: %s',
                    $serviceRequest->getId(),
                    $e->getMessage()
                ));
            }
        }

        if (!$dryRun) {
            $this->entityManager->flush();
        }

        $progressBar->finish();
        $io->newLine(2);

        return $stats;
    }
}

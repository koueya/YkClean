<?php

namespace App\Service\Geocoding;

use Psr\Log\LoggerInterface;
use Symfony\Contracts\Cache\CacheInterface;
use Symfony\Contracts\Cache\ItemInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

/**
 * Service de géocodage avec support multi-provider et cache
 * 
 * Providers supportés :
 * - Nominatim (OpenStreetMap) - Gratuit
 * - Google Maps Geocoding API - Payant
 */
class GeocodingService
{
    private const CACHE_TTL = 2592000; // 30 jours
    private const NOMINATIM_ENDPOINT = 'https://nominatim.openstreetmap.org/search';
    private const GOOGLE_ENDPOINT = 'https://maps.googleapis.com/maps/api/geocode/json';
    
    private string $defaultProvider = 'nominatim';
    private ?string $googleApiKey = null;
    private string $userAgent;

    public function __construct(
        private HttpClientInterface $httpClient,
        private CacheInterface $cache,
        private LoggerInterface $logger,
        string $googleMapsApiKey = null,
        string $userAgent = 'CleanServiceApp/1.0'
    ) {
        $this->googleApiKey = $googleMapsApiKey;
        $this->userAgent = $userAgent;
        
        // Utiliser Google si la clé API est configurée
        if ($googleMapsApiKey) {
            $this->defaultProvider = 'google';
        }
    }

    /**
     * Géocode une adresse complète
     * 
     * @param string $address Adresse complète
     * @param string $postalCode Code postal (optionnel)
     * @param string $city Ville (optionnel)
     * @param string|null $provider Provider à utiliser (null = par défaut)
     * @return array|null ['latitude' => float, 'longitude' => float, 'formatted_address' => string]
     */
    public function geocode(
        string $address,
        ?string $postalCode = null,
        ?string $city = null,
        ?string $provider = null
    ): ?array {
        // Construire l'adresse complète
        $fullAddress = $this->buildFullAddress($address, $postalCode, $city);
        
        if (empty($fullAddress)) {
            $this->logger->warning('Empty address provided for geocoding');
            return null;
        }

        // Créer une clé de cache
        $cacheKey = $this->getCacheKey($fullAddress);

        try {
            // Vérifier le cache
            return $this->cache->get($cacheKey, function (ItemInterface $item) use ($fullAddress, $provider) {
                $item->expiresAfter(self::CACHE_TTL);

                // Choisir le provider
                $providerToUse = $provider ?? $this->defaultProvider;

                // Géocoder selon le provider
                $result = match($providerToUse) {
                    'google' => $this->geocodeWithGoogle($fullAddress),
                    'nominatim' => $this->geocodeWithNominatim($fullAddress),
                    default => throw new \InvalidArgumentException("Unknown provider: {$providerToUse}")
                };

                if ($result) {
                    $this->logger->info('Address geocoded successfully', [
                        'address' => $fullAddress,
                        'provider' => $providerToUse,
                        'coordinates' => $result,
                    ]);
                }

                return $result;
            });

        } catch (\Exception $e) {
            $this->logger->error('Geocoding failed', [
                'address' => $fullAddress,
                'error' => $e->getMessage(),
            ]);

            // Fallback : essayer l'autre provider
            if ($provider !== 'nominatim' && $this->defaultProvider !== 'nominatim') {
                $this->logger->info('Trying fallback to Nominatim');
                return $this->geocode($address, $postalCode, $city, 'nominatim');
            }

            return null;
        }
    }

    /**
     * Géocode avec Google Maps Geocoding API
     */
    private function geocodeWithGoogle(string $address): ?array
    {
        if (!$this->googleApiKey) {
            throw new \RuntimeException('Google Maps API key not configured');
        }

        $url = self::GOOGLE_ENDPOINT . '?' . http_build_query([
            'address' => $address,
            'key' => $this->googleApiKey,
            'language' => 'fr',
            'region' => 'fr',
        ]);

        try {
            $response = $this->httpClient->request('GET', $url);
            $data = $response->toArray();

            if ($data['status'] !== 'OK' || empty($data['results'])) {
                $this->logger->warning('Google Geocoding returned no results', [
                    'address' => $address,
                    'status' => $data['status'],
                ]);
                return null;
            }

            $result = $data['results'][0];
            $location = $result['geometry']['location'];

            return [
                'latitude' => (float) $location['lat'],
                'longitude' => (float) $location['lng'],
                'formatted_address' => $result['formatted_address'],
                'provider' => 'google',
            ];

        } catch (\Exception $e) {
            $this->logger->error('Google Geocoding API error', [
                'address' => $address,
                'error' => $e->getMessage(),
            ]);
            throw $e;
        }
    }

    /**
     * Géocode avec Nominatim (OpenStreetMap)
     */
    private function geocodeWithNominatim(string $address): ?array
    {
        $url = self::NOMINATIM_ENDPOINT . '?' . http_build_query([
            'q' => $address,
            'format' => 'json',
            'addressdetails' => 1,
            'limit' => 1,
            'countrycodes' => 'fr',
        ]);

        try {
            $response = $this->httpClient->request('GET', $url, [
                'headers' => [
                    'User-Agent' => $this->userAgent,
                ],
            ]);

            // Respecter la limite de taux de Nominatim (1 req/sec)
            sleep(1);

            $data = $response->toArray();

            if (empty($data)) {
                $this->logger->warning('Nominatim returned no results', [
                    'address' => $address,
                ]);
                return null;
            }

            $result = $data[0];

            return [
                'latitude' => (float) $result['lat'],
                'longitude' => (float) $result['lon'],
                'formatted_address' => $result['display_name'],
                'provider' => 'nominatim',
            ];

        } catch (\Exception $e) {
            $this->logger->error('Nominatim API error', [
                'address' => $address,
                'error' => $e->getMessage(),
            ]);
            throw $e;
        }
    }

    /**
     * Géocode inversé (coordonnées -> adresse)
     */
    public function reverseGeocode(
        float $latitude,
        float $longitude,
        ?string $provider = null
    ): ?array {
        $providerToUse = $provider ?? $this->defaultProvider;

        try {
            return match($providerToUse) {
                'google' => $this->reverseGeocodeWithGoogle($latitude, $longitude),
                'nominatim' => $this->reverseGeocodeWithNominatim($latitude, $longitude),
                default => throw new \InvalidArgumentException("Unknown provider: {$providerToUse}")
            };

        } catch (\Exception $e) {
            $this->logger->error('Reverse geocoding failed', [
                'latitude' => $latitude,
                'longitude' => $longitude,
                'error' => $e->getMessage(),
            ]);
            return null;
        }
    }

    /**
     * Géocode inversé avec Google
     */
    private function reverseGeocodeWithGoogle(float $latitude, float $longitude): ?array
    {
        if (!$this->googleApiKey) {
            throw new \RuntimeException('Google Maps API key not configured');
        }

        $url = self::GOOGLE_ENDPOINT . '?' . http_build_query([
            'latlng' => "{$latitude},{$longitude}",
            'key' => $this->googleApiKey,
            'language' => 'fr',
        ]);

        $response = $this->httpClient->request('GET', $url);
        $data = $response->toArray();

        if ($data['status'] !== 'OK' || empty($data['results'])) {
            return null;
        }

        $result = $data['results'][0];

        return [
            'formatted_address' => $result['formatted_address'],
            'address_components' => $result['address_components'],
            'provider' => 'google',
        ];
    }

    /**
     * Géocode inversé avec Nominatim
     */
    private function reverseGeocodeWithNominatim(float $latitude, float $longitude): ?array
    {
        $url = 'https://nominatim.openstreetmap.org/reverse?' . http_build_query([
            'lat' => $latitude,
            'lon' => $longitude,
            'format' => 'json',
            'addressdetails' => 1,
        ]);

        $response = $this->httpClient->request('GET', $url, [
            'headers' => [
                'User-Agent' => $this->userAgent,
            ],
        ]);

        sleep(1); // Respecter la limite de taux

        $data = $response->toArray();

        if (empty($data)) {
            return null;
        }

        return [
            'formatted_address' => $data['display_name'],
            'address_components' => $data['address'],
            'provider' => 'nominatim',
        ];
    }

    /**
     * Construit l'adresse complète à partir des composants
     */
    private function buildFullAddress(?string $address, ?string $postalCode, ?string $city): string
    {
        $parts = array_filter([
            $address,
            $postalCode,
            $city,
            'France', // Ajouter le pays par défaut
        ]);

        return implode(', ', $parts);
    }

    /**
     * Génère une clé de cache pour une adresse
     */
    private function getCacheKey(string $address): string
    {
        return 'geocode_' . md5(strtolower(trim($address)));
    }

    /**
     * Nettoie le cache de géocodage
     */
    public function clearCache(?string $address = null): bool
    {
        try {
            if ($address) {
                $cacheKey = $this->getCacheKey($address);
                $this->cache->delete($cacheKey);
                $this->logger->info('Geocoding cache cleared for address', ['address' => $address]);
            } else {
                // Note: Nécessite un cache pool avec clear()
                // $this->cache->clear();
                $this->logger->info('Full geocoding cache cleared');
            }
            return true;
        } catch (\Exception $e) {
            $this->logger->error('Failed to clear geocoding cache', [
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * Batch geocoding pour plusieurs adresses
     */
    public function geocodeBatch(array $addresses, ?string $provider = null): array
    {
        $results = [];
        $delayBetweenRequests = ($provider === 'nominatim' || $this->defaultProvider === 'nominatim') ? 1 : 0.1;

        foreach ($addresses as $key => $addressData) {
            $result = $this->geocode(
                $addressData['address'] ?? '',
                $addressData['postal_code'] ?? null,
                $addressData['city'] ?? null,
                $provider
            );

            $results[$key] = $result;

            // Délai entre les requêtes
            if (next($addresses) !== false) {
                usleep($delayBetweenRequests * 1000000);
            }
        }

        return $results;
    }

    /**
     * Validation des coordonnées GPS
     */
    public function validateCoordinates(float $latitude, float $longitude): bool
    {
        return $latitude >= -90 && $latitude <= 90 &&
               $longitude >= -180 && $longitude <= 180;
    }

    /**
     * Obtient des statistiques sur le cache
     */
    public function getCacheStats(): array
    {
        // Note: Dépend de l'implémentation du cache
        // À adapter selon votre configuration
        return [
            'provider' => $this->defaultProvider,
            'cache_ttl' => self::CACHE_TTL,
            'google_api_configured' => $this->googleApiKey !== null,
        ];
    }
}

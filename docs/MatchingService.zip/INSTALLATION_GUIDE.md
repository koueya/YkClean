# 🚀 Guide d'Installation du Système de Matching Harmonisé

## 📦 Fichiers Livrés

Ce package contient tous les fichiers nécessaires pour mettre en place le système de matching harmonisé :

1. **MatchingService.php** - Service principal de matching
2. **GeocodingService.php** - Service de géocodage avec cache
3. **GeocodeAddressesCommand.php** - Commande pour géocoder les adresses existantes
4. **migration_add_gps_coordinates.sql** - Migration SQL pour ajouter les coordonnées GPS
5. **MATCHING_SERVICE_README.md** - Documentation complète du système

## 🔧 Installation Étape par Étape

### Étape 1 : Copier les Fichiers

```bash
# Copier le service de matching
cp MatchingService.php backend/src/Service/Matching/MatchingService.php

# Copier le service de géocodage
cp GeocodingService.php backend/src/Service/Geocoding/GeocodingService.php

# Copier la commande
cp GeocodeAddressesCommand.php backend/src/Command/GeocodeAddressesCommand.php
```

### Étape 2 : Exécuter la Migration SQL

```bash
# Via MySQL CLI
mysql -u username -p database_name < migration_add_gps_coordinates.sql

# Ou via Symfony (créer une migration Doctrine)
php bin/console make:migration
# Puis copier le contenu SQL dans la migration générée
php bin/console doctrine:migrations:migrate
```

### Étape 3 : Mettre à Jour les Entités Doctrine

#### Prestataire.php

Ajouter ces propriétés et méthodes :

```php
<?php
namespace App\Entity\User;

use Doctrine\ORM\Mapping as ORM;

class Prestataire extends User
{
    // ... existing code ...

    #[ORM\Column(type: 'decimal', precision: 10, scale: 8, nullable: true)]
    private ?float $latitude = null;

    #[ORM\Column(type: 'decimal', precision: 11, scale: 8, nullable: true)]
    private ?float $longitude = null;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private ?\DateTimeInterface $geocodedAt = null;

    #[ORM\Column(type: 'integer', nullable: true)]
    private ?int $serviceRadius = 50; // Rayon d'intervention en km

    public function getLatitude(): ?float
    {
        return $this->latitude;
    }

    public function setLatitude(?float $latitude): self
    {
        $this->latitude = $latitude;
        return $this;
    }

    public function getLongitude(): ?float
    {
        return $this->longitude;
    }

    public function setLongitude(?float $longitude): self
    {
        $this->longitude = $longitude;
        return $this;
    }

    public function getGeocodedAt(): ?\DateTimeInterface
    {
        return $this->geocodedAt;
    }

    public function setGeocodedAt(?\DateTimeInterface $geocodedAt): self
    {
        $this->geocodedAt = $geocodedAt;
        return $this;
    }

    public function getServiceRadius(): ?int
    {
        return $this->serviceRadius;
    }

    public function setServiceRadius(?int $serviceRadius): self
    {
        $this->serviceRadius = $serviceRadius;
        return $this;
    }

    /**
     * Méthodes helper nécessaires pour le matching
     */
    
    public function getAverageRating(): ?float
    {
        // À implémenter selon votre logique de notation
        // Exemple : calculer la moyenne des reviews
        return $this->averageRating ?? null;
    }

    public function getCompletedBookingsCount(): int
    {
        // À implémenter selon votre logique
        // Exemple : compter les bookings avec status 'completed'
        return $this->completedBookingsCount ?? 0;
    }

    public function getResponseRate(): float
    {
        // À implémenter selon votre logique
        // Exemple : (devis envoyés / demandes reçues) * 100
        return $this->responseRate ?? 70.0;
    }
}
```

#### ServiceRequest.php

Ajouter ces propriétés et méthodes :

```php
<?php
namespace App\Entity\Service;

use Doctrine\ORM\Mapping as ORM;

class ServiceRequest
{
    // ... existing code ...

    #[ORM\Column(type: 'decimal', precision: 10, scale: 8, nullable: true)]
    private ?float $latitude = null;

    #[ORM\Column(type: 'decimal', precision: 11, scale: 8, nullable: true)]
    private ?float $longitude = null;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private ?\DateTimeInterface $geocodedAt = null;

    public function getLatitude(): ?float
    {
        return $this->latitude;
    }

    public function setLatitude(?float $latitude): self
    {
        $this->latitude = $latitude;
        return $this;
    }

    public function getLongitude(): ?float
    {
        return $this->longitude;
    }

    public function setLongitude(?float $longitude): self
    {
        $this->longitude = $longitude;
        return $this;
    }

    public function getGeocodedAt(): ?\DateTimeInterface
    {
        return $this->geocodedAt;
    }

    public function setGeocodedAt(?\DateTimeInterface $geocodedAt): self
    {
        $this->geocodedAt = $geocodedAt;
        return $this;
    }
}
```

### Étape 4 : Configurer les Services

#### config/services.yaml

```yaml
services:
    # Service de géocodage
    App\Service\Geocoding\GeocodingService:
        arguments:
            $googleMapsApiKey: '%env(GOOGLE_MAPS_API_KEY)%'
            $userAgent: '%env(APP_NAME)%/1.0'

    # Service de matching
    App\Service\Matching\MatchingService:
        arguments:
            $entityManager: '@doctrine.orm.entity_manager'
            $prestataireRepository: '@App\Repository\User\PrestataireRepository'
            $serviceRequestRepository: '@App\Repository\Service\ServiceRequestRepository'
            $availabilityRepository: '@App\Repository\Planning\AvailabilityRepository'
            $quoteRepository: '@App\Repository\Quote\QuoteRepository'
            $logger: '@logger'
```

#### .env

```bash
###> Geocoding Configuration ###
# Google Maps API Key (optionnel - utilise Nominatim par défaut)
GOOGLE_MAPS_API_KEY=

# Nom de l'application pour Nominatim
APP_NAME=CleanService
###< Geocoding Configuration ###
```

### Étape 5 : Implémenter les Méthodes de Repository Manquantes

#### PrestataireRepository.php

```php
<?php
namespace App\Repository\User;

use App\Entity\Service\ServiceCategory;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class PrestataireRepository extends ServiceEntityRepository
{
    // ... existing code ...

    /**
     * Trouve les prestataires éligibles pour une demande de service
     * 
     * @param ServiceCategory $category Catégorie de service
     * @param float $latitude Latitude du client
     * @param float $longitude Longitude du client
     * @param float $maxDistance Distance maximum en km
     * @return array
     */
    public function findEligibleForServiceRequest(
        ServiceCategory $category,
        float $latitude,
        float $longitude,
        float $maxDistance
    ): array {
        // Formule de Haversine pour calculer la distance
        $earthRadius = 6371; // en km

        $qb = $this->createQueryBuilder('p')
            ->leftJoin('p.serviceCategories', 'sc')
            ->where('p.isApproved = :approved')
            ->andWhere('p.isActive = :active')
            ->andWhere('sc = :category')
            ->andWhere('p.latitude IS NOT NULL')
            ->andWhere('p.longitude IS NOT NULL')
            ->setParameter('approved', true)
            ->setParameter('active', true)
            ->setParameter('category', $category);

        // Filtre par distance (approximation rapide avec bounding box)
        // Plus précis que calculer la distance Haversine pour chaque résultat
        $latDelta = $maxDistance / 111; // 1 degré de latitude ≈ 111 km
        $lonDelta = $maxDistance / (111 * cos(deg2rad($latitude)));

        $qb->andWhere('p.latitude BETWEEN :minLat AND :maxLat')
           ->andWhere('p.longitude BETWEEN :minLon AND :maxLon')
           ->setParameter('minLat', $latitude - $latDelta)
           ->setParameter('maxLat', $latitude + $latDelta)
           ->setParameter('minLon', $longitude - $lonDelta)
           ->setParameter('maxLon', $longitude + $lonDelta);

        return $qb->getQuery()->getResult();
    }
}
```

#### AvailabilityRepository.php

```php
<?php
namespace App\Repository\Planning;

use App\Entity\User\Prestataire;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class AvailabilityRepository extends ServiceEntityRepository
{
    // ... existing code ...

    /**
     * Trouve les disponibilités d'un prestataire pour une date donnée
     * 
     * @param Prestataire $prestataire
     * @param \DateTimeInterface $date
     * @return array
     */
    public function findByPrestataireAndDate(
        Prestataire $prestataire,
        \DateTimeInterface $date
    ): array {
        $dayOfWeek = (int) $date->format('w'); // 0 (dimanche) à 6 (samedi)

        return $this->createQueryBuilder('a')
            ->where('a.prestataire = :prestataire')
            ->andWhere(
                $this->createQueryBuilder('a')->expr()->orX(
                    // Disponibilité récurrente pour ce jour
                    $this->createQueryBuilder('a')->expr()->andX(
                        'a.isRecurring = :recurring',
                        'a.dayOfWeek = :dayOfWeek'
                    ),
                    // Disponibilité spécifique pour cette date
                    $this->createQueryBuilder('a')->expr()->andX(
                        'a.isRecurring = :notRecurring',
                        'a.specificDate = :specificDate'
                    )
                )
            )
            ->setParameter('prestataire', $prestataire)
            ->setParameter('recurring', true)
            ->setParameter('notRecurring', false)
            ->setParameter('dayOfWeek', $dayOfWeek)
            ->setParameter('specificDate', $date->format('Y-m-d'))
            ->getQuery()
            ->getResult();
    }
}
```

### Étape 6 : Géocoder les Adresses Existantes

```bash
# Géocoder toutes les adresses (utilise Nominatim par défaut)
php bin/console app:geocode:addresses

# Avec Google Maps (si API key configurée)
php bin/console app:geocode:addresses --provider=google

# Dry-run pour tester
php bin/console app:geocode:addresses --dry-run

# Limiter le nombre
php bin/console app:geocode:addresses --limit=100
```

### Étape 7 : Mettre à Jour le ServiceRequestController (si nécessaire)

Le `ServiceRequestController` du prestataire devrait maintenant fonctionner sans modification car toutes les méthodes nécessaires sont présentes dans le `MatchingService` harmonisé.

Si vous aviez des imports incorrects, mettez-les à jour :

```php
<?php
namespace App\Controller\Api\Prestataire;

use App\Service\Matching\MatchingService; // ✅ Correct
// use App\Service\MatchingService; // ❌ Ancien import incorrect

class ServiceRequestController extends AbstractController
{
    public function __construct(
        // ... autres dépendances ...
        private MatchingService $matchingService
    ) {
    }
    
    // ... le reste du code reste identique
}
```

### Étape 8 : Créer un Event Listener pour Géocodage Automatique (Optionnel)

Pour géocoder automatiquement les nouvelles adresses :

```php
<?php
// src/EventListener/GeocodingListener.php

namespace App\EventListener;

use App\Entity\User\Prestataire;
use App\Entity\Service\ServiceRequest;
use App\Service\Geocoding\GeocodingService;
use Doctrine\Bundle\DoctrineBundle\Attribute\AsEntityListener;
use Doctrine\ORM\Events;
use Doctrine\Persistence\Event\LifecycleEventArgs;
use Psr\Log\LoggerInterface;

#[AsEntityListener(event: Events::prePersist, entity: Prestataire::class)]
#[AsEntityListener(event: Events::preUpdate, entity: Prestataire::class)]
#[AsEntityListener(event: Events::prePersist, entity: ServiceRequest::class)]
#[AsEntityListener(event: Events::preUpdate, entity: ServiceRequest::class)]
class GeocodingListener
{
    public function __construct(
        private GeocodingService $geocodingService,
        private LoggerInterface $logger
    ) {}

    public function prePersist(LifecycleEventArgs $args): void
    {
        $this->geocodeEntity($args->getObject());
    }

    public function preUpdate(LifecycleEventArgs $args): void
    {
        $this->geocodeEntity($args->getObject());
    }

    private function geocodeEntity(object $entity): void
    {
        if (!$entity instanceof Prestataire && !$entity instanceof ServiceRequest) {
            return;
        }

        // Géocoder si pas encore fait ou si l'adresse a changé
        if ($this->shouldGeocode($entity)) {
            try {
                $result = $this->geocodingService->geocode(
                    $entity->getAddress(),
                    $entity->getPostalCode(),
                    $entity->getCity()
                );

                if ($result) {
                    $entity->setLatitude($result['latitude']);
                    $entity->setLongitude($result['longitude']);
                    $entity->setGeocodedAt(new \DateTime());
                }
            } catch (\Exception $e) {
                $this->logger->error('Auto-geocoding failed', [
                    'entity' => get_class($entity),
                    'id' => $entity->getId(),
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }

    private function shouldGeocode(Prestataire|ServiceRequest $entity): bool
    {
        // Géocoder si pas de coordonnées
        if ($entity->getLatitude() === null || $entity->getLongitude() === null) {
            return true;
        }

        // TODO: Détecter si l'adresse a changé
        // Nécessite de comparer avec les valeurs d'origine via UnitOfWork
        
        return false;
    }
}
```

Enregistrer le listener dans `services.yaml` :

```yaml
services:
    App\EventListener\GeocodingListener:
        tags:
            - { name: 'doctrine.orm.entity_listener' }
```

## ✅ Vérification de l'Installation

### Test 1 : Vérifier que les Services sont Configurés

```bash
php bin/console debug:container MatchingService
php bin/console debug:container GeocodingService
```

### Test 2 : Tester le Géocodage

```bash
# Géocoder une adresse de test
php bin/console app:geocode:addresses --limit=1 --dry-run
```

### Test 3 : Tester l'API de Matching

```bash
# Via curl ou Postman
curl -X GET "http://localhost:8000/api/prestataire/service-requests/available" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Test 4 : Vérifier les Coordonnées en Base

```sql
-- Vérifier les prestataires géocodés
SELECT id, email, latitude, longitude, geocoded_at 
FROM prestataire 
WHERE latitude IS NOT NULL 
LIMIT 10;

-- Vérifier les service requests géocodés
SELECT id, address, latitude, longitude, geocoded_at 
FROM service_request 
WHERE latitude IS NOT NULL 
LIMIT 10;
```

## 🐛 Debugging

### Problème : Service non trouvé

```bash
# Vider le cache Symfony
php bin/console cache:clear

# Vérifier l'autowiring
php bin/console debug:autowiring Matching
```

### Problème : Erreur de géocodage

```bash
# Vérifier les logs
tail -f var/log/dev.log | grep -i geocod

# Tester manuellement avec Nominatim
curl "https://nominatim.openstreetmap.org/search?q=Paris,France&format=json"
```

### Problème : Performances lentes

```bash
# Activer le profiler Symfony pour analyser
# Vérifier les requêtes N+1
php bin/console debug:container doctrine.orm.default_query_sql_logger

# Créer les index manquants
# (Voir la section index dans migration_add_gps_coordinates.sql)
```

## 📚 Documentation Complémentaire

- **MATCHING_SERVICE_README.md** : Documentation détaillée du système
- Code inline dans les fichiers sources
- Exemples d'utilisation dans les tests

## 🎯 Prochaines Étapes

1. ✅ Installer et tester le système de base
2. ⏳ Ajuster les poids de matching selon vos besoins
3. ⏳ Implémenter les méthodes helper manquantes (averageRating, etc.)
4. ⏳ Configurer l'API Google Maps si nécessaire
5. ⏳ Mettre en place le monitoring et les statistiques
6. ⏳ Optimiser les performances avec Redis cache

## 💡 Conseils

- **Testez d'abord en environnement de dev** avec `--dry-run`
- **Utilisez Nominatim** pour commencer (gratuit)
- **Passez à Google Maps** si vous avez besoin de meilleures performances
- **Géocodez progressivement** les adresses existantes (par batch de 100)
- **Surveillez les logs** pour détecter les problèmes
- **Optimisez le cache** pour réduire les appels API

## 🆘 Support

En cas de problème :

1. Vérifier les logs : `var/log/dev.log`
2. Consulter la documentation : `MATCHING_SERVICE_README.md`
3. Vérifier la configuration des services
4. Tester avec `--dry-run` et `--limit=1`

---

**Bonne installation ! 🚀**

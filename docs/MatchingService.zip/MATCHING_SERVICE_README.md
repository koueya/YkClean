# Service de Matching Harmonisé

## 📋 Vue d'ensemble

Ce document détaille les modifications apportées au système de matching pour résoudre l'erreur d'autowiring et harmoniser les services.

## ⚠️ Problème Initial

```
Cannot autowire service "App\Controller\Api\Prestataire\ServiceRequestController": 
argument "$matchingService" of method "__construct()" has type "App\Service\MatchingService"
```

Le `ServiceRequestController` utilisait `MatchingService` mais appelait des méthodes qui n'existaient pas ou qui avaient des signatures différentes entre les deux services de matching.

## ✅ Solution Implémentée

### 1. Service Unifié

Un seul service `MatchingService` harmonisé qui combine :
- La structure robuste du `MatchingService` original
- Les méthodes spécifiques nécessaires au `ServiceRequestController`
- Toutes les fonctionnalités des deux services précédents

### 2. Méthodes Clés Ajoutées/Modifiées

#### `findMatchingRequests(Prestataire $prestataire, array $options)`

**Utilisé par:** `ServiceRequestController::available()`

**Fonctionnalité:**
- Trouve les demandes de service correspondant au profil d'un prestataire
- Supporte la pagination
- Filtre automatiquement les demandes déjà cotées
- Calcule le score de matching pour chaque demande
- Retourne un tableau avec `['requests' => [...], 'total' => int]`

**Options supportées:**
```php
[
    'page' => 1,              // Numéro de page
    'limit' => 20,            // Nombre de résultats par page
    'category_id' => null,    // ID catégorie spécifique
    'max_distance' => 50,     // Distance max en km
    'sort_by' => 'created_at' // Tri: created_at, budget, distance, score
]
```

#### `getRecommendations(Prestataire $prestataire, int $limit)`

**Utilisé par:** `ServiceRequestController::recommended()`

**Fonctionnalité:**
- Retourne les meilleures recommandations pour un prestataire
- Utilise le tri par score pour prioriser les meilleurs matches
- Limite configurable

#### `calculateDistance(float $lat1, float $lon1, float $lat2, float $lon2)`

**Utilisé par:** `ServiceRequestController::show()`

**Fonctionnalité:**
- Méthode publique (était privée)
- Calcule la distance entre deux points GPS
- Utilise la formule de Haversine
- Retourne la distance en kilomètres

#### `findReplacementPrestataire(Booking $booking, ?Prestataire $excludePrestataire)`

**Utilisé par:** Système de remplacement

**Fonctionnalité:**
- Trouve des prestataires de remplacement pour une réservation
- Exclut le prestataire original
- Filtre par disponibilité à la date exacte

### 3. Algorithme de Scoring

Le système utilise un scoring pondéré basé sur 6 critères :

| Critère | Poids | Description |
|---------|-------|-------------|
| Distance | 30% | Proximité géographique |
| Disponibilité | 25% | Disponible aux dates demandées |
| Note moyenne | 20% | Évaluation par les clients |
| Expérience | 10% | Nombre de services complétés |
| Prix | 10% | Compatibilité avec le budget |
| Taux de réponse | 5% | Réactivité du prestataire |

**Score minimum requis:** 40/100

### 4. Système de Filtrage

Filtres disponibles pour affiner les résultats :

```php
[
    'min_rating' => 3.0,        // Note minimum
    'max_price' => 50.0,        // Tarif horaire maximum
    'available_now' => true,    // Disponibilité immédiate
    'min_score' => 60,          // Score minimum
    'min_experience' => 10,     // Nombre min de services
    'max_distance' => 30        // Distance max en km
]
```

### 5. Tri des Résultats

Options de tri supportées :

- **`score`** : Par score de matching (décroissant)
- **`distance`** : Par distance (croissant)
- **`budget`** : Par budget (décroissant)
- **`created_at`** : Par date de création (décroissant) - défaut

## 🔧 Configuration Requise

### services.yaml

```yaml
services:
    App\Service\Matching\MatchingService:
        arguments:
            $entityManager: '@doctrine.orm.entity_manager'
            $prestataireRepository: '@App\Repository\User\PrestataireRepository'
            $serviceRequestRepository: '@App\Repository\Service\ServiceRequestRepository'
            $availabilityRepository: '@App\Repository\Planning\AvailabilityRepository'
            $quoteRepository: '@App\Repository\Quote\QuoteRepository'
            $logger: '@logger'
```

### Repository Methods Required

Le service nécessite ces méthodes dans les repositories :

#### PrestataireRepository

```php
public function findEligibleForServiceRequest(
    ServiceCategory $category,
    float $latitude,
    float $longitude,
    float $maxDistance
): array
```

#### ServiceRequestRepository

- Méthodes standards de Doctrine

#### AvailabilityRepository

```php
public function findByPrestataireAndDate(
    Prestataire $prestataire,
    \DateTimeInterface $date
): array
```

## 📊 Flux de Matching

### Pour le Client (Trouver des Prestataires)

```
Client crée ServiceRequest
    ↓
findMatchingPrestataires(ServiceRequest, limit, filters)
    ↓
1. Géocoder l'adresse client
2. Récupérer prestataires éligibles (catégorie + distance)
3. Calculer score pour chaque prestataire
4. Filtrer par score minimum (40)
5. Appliquer filtres additionnels
6. Trier par score décroissant
7. Paginer et retourner
```

### Pour le Prestataire (Voir les Demandes)

```
Prestataire consulte les demandes
    ↓
findMatchingRequests(Prestataire, options)
    ↓
1. Géocoder l'adresse prestataire
2. Récupérer demandes ouvertes de ses catégories
3. Filtrer les demandes déjà cotées
4. Calculer distance et score pour chaque demande
5. Filtrer par distance max
6. Filtrer par score minimum (40)
7. Trier selon critère (score, date, budget, distance)
8. Paginer et retourner
```

## 🚀 Utilisation dans le Controller

### Exemple 1 : Liste des Demandes Disponibles

```php
public function available(Request $request): JsonResponse
{
    $prestataire = $this->getUser();
    
    $result = $this->matchingService->findMatchingRequests(
        $prestataire,
        [
            'page' => $request->query->get('page', 1),
            'limit' => $request->query->get('limit', 20),
            'category_id' => $request->query->get('category_id'),
            'max_distance' => $request->query->get('max_distance', 50),
            'sort_by' => $request->query->get('sort_by', 'created_at'),
        ]
    );
    
    return $this->json([
        'success' => true,
        'data' => $result['requests'],
        'meta' => [
            'total' => $result['total'],
            'page' => $page,
            'limit' => $limit,
        ],
    ]);
}
```

### Exemple 2 : Recommandations

```php
public function recommended(Request $request): JsonResponse
{
    $prestataire = $this->getUser();
    $limit = $request->query->get('limit', 10);
    
    $recommendations = $this->matchingService->getRecommendations(
        $prestataire, 
        $limit
    );
    
    return $this->json([
        'success' => true,
        'data' => $recommendations,
    ]);
}
```

### Exemple 3 : Afficher avec Distance

```php
public function show(ServiceRequest $serviceRequest): JsonResponse
{
    $prestataire = $this->getUser();
    
    $distance = null;
    if ($prestataire->getLatitude() && $serviceRequest->getLatitude()) {
        $distance = $this->matchingService->calculateDistance(
            $prestataire->getLatitude(),
            $prestataire->getLongitude(),
            $serviceRequest->getLatitude(),
            $serviceRequest->getLongitude()
        );
    }
    
    return $this->json([
        'success' => true,
        'data' => $serviceRequest,
        'meta' => [
            'distance_km' => $distance,
        ],
    ]);
}
```

## ⚡ Optimisations

### 1. Géocodage avec Cache

Le géocodage est coûteux. Implémentez un cache :

```php
// Dans geocodeAddress()
$cacheKey = 'geocode_' . md5($address);

// Vérifier le cache Redis
$cached = $redis->get($cacheKey);
if ($cached) {
    return json_decode($cached, true);
}

// Appel API géocodage
$coordinates = $this->callGeocodingAPI($address);

// Mettre en cache (7 jours)
$redis->setex($cacheKey, 604800, json_encode($coordinates));

return $coordinates;
```

### 2. Index Base de Données

Créez des index pour améliorer les performances :

```sql
-- Pour les recherches géographiques
CREATE INDEX idx_prestataire_location ON prestataire(latitude, longitude);
CREATE INDEX idx_service_request_location ON service_request(latitude, longitude);

-- Pour les recherches par statut
CREATE INDEX idx_service_request_status ON service_request(status);

-- Pour les recherches par catégorie
CREATE INDEX idx_prestataire_categories ON prestataire_service_category(prestataire_id, service_category_id);
```

### 3. Pagination Efficace

Utilisez la pagination native de Doctrine :

```php
// Dans findMatchingRequests()
$query = $qb->getQuery();
$query->setFirstResult(($page - 1) * $limit);
$query->setMaxResults($limit);
```

## 🧪 Tests

### Test Unitaire du Score

```php
public function testCalculateMatchingScore()
{
    $serviceRequest = $this->createServiceRequest([
        'budget' => 30,
        'preferred_date' => new \DateTime('+7 days'),
    ]);
    
    $prestataire = $this->createPrestataire([
        'hourly_rate' => 28,
        'average_rating' => 4.5,
        'completed_bookings' => 25,
    ]);
    
    $coordinates = ['latitude' => 48.8566, 'longitude' => 2.3522];
    
    $score = $this->matchingService->calculateMatchingScore(
        $serviceRequest,
        $prestataire,
        $coordinates
    );
    
    $this->assertGreaterThan(60, $score['total_score']);
    $this->assertEquals(6, count($score['details']));
}
```

### Test d'Intégration

```php
public function testFindMatchingRequests()
{
    $prestataire = $this->createApprovedPrestataire();
    
    // Créer quelques demandes
    $this->createServiceRequest(['category' => 'cleaning']);
    $this->createServiceRequest(['category' => 'ironing']);
    
    $result = $this->matchingService->findMatchingRequests(
        $prestataire,
        ['limit' => 10, 'page' => 1]
    );
    
    $this->assertArrayHasKey('requests', $result);
    $this->assertArrayHasKey('total', $result);
    $this->assertIsArray($result['requests']);
}
```

## 📝 TODO / Améliorations Futures

### Haute Priorité

1. **Implémenter le géocodage réel**
   - Intégrer Google Maps Geocoding API ou Nominatim
   - Ajouter un système de cache Redis
   - Gérer les erreurs et limites de taux

2. **Stocker les coordonnées GPS**
   - Ajouter `latitude` et `longitude` aux entités Prestataire et ServiceRequest
   - Géocoder lors de la création/modification d'adresse
   - Créer une migration pour les données existantes

3. **Optimiser les requêtes**
   - Implémenter `findEligibleForServiceRequest` avec requête SQL optimisée
   - Utiliser des jointures pour réduire les requêtes N+1
   - Ajouter des index géospatiaux

### Moyenne Priorité

4. **Améliorer le scoring**
   - Ajouter un poids pour la proximité de la date préférée
   - Prendre en compte l'historique entre client et prestataire
   - Ajuster dynamiquement les poids selon le contexte

5. **Machine Learning**
   - Collecter les données sur les matches réussis/échoués
   - Entraîner un modèle pour améliorer les recommandations
   - Personnaliser les poids par utilisateur

6. **Système de feedback**
   - Tracker les vues de demandes
   - Mesurer le taux de conversion (vue → devis → réservation)
   - Ajuster l'algorithme selon les résultats

### Basse Priorité

7. **Interface d'administration**
   - Dashboard pour voir les statistiques de matching
   - Outil pour ajuster les poids en temps réel
   - Visualisation des résultats de matching

8. **A/B Testing**
   - Tester différents algorithmes de scoring
   - Comparer les taux de conversion
   - Optimiser progressivement

## 🔐 Sécurité

- ✅ Vérification que le prestataire est approuvé
- ✅ Filtrage des demandes déjà cotées
- ✅ Validation des paramètres d'entrée
- ✅ Limitation de la pagination (max 100 résultats)
- ✅ Logs des erreurs et avertissements

## 📚 Ressources

- [Formule de Haversine](https://en.wikipedia.org/wiki/Haversine_formula)
- [Google Geocoding API](https://developers.google.com/maps/documentation/geocoding)
- [Nominatim (OpenStreetMap)](https://nominatim.org/)
- [Algorithmes de Matching](https://en.wikipedia.org/wiki/Matching_(graph_theory))

## 👥 Support

En cas de problème :
1. Vérifier les logs : `var/log/dev.log`
2. Activer le debug SQL : `doctrine.dbal.logging: true`
3. Vérifier que les repositories ont les bonnes méthodes
4. Vérifier la configuration du service dans `services.yaml`

---

**Version:** 1.0.0  
**Date:** 2025-01-31  
**Auteur:** Système de Matching Harmonisé

-- Migration : Ajout des coordonnées GPS pour le système de matching
-- Date : 2025-01-31
-- Description : Ajoute les colonnes latitude et longitude aux tables prestataire et service_request

-- =====================================================
-- Table: prestataire
-- =====================================================

-- Ajouter les colonnes GPS
ALTER TABLE prestataire 
ADD COLUMN latitude DECIMAL(10, 8) NULL COMMENT 'Latitude GPS de l\'adresse',
ADD COLUMN longitude DECIMAL(11, 8) NULL COMMENT 'Longitude GPS de l\'adresse',
ADD COLUMN geocoded_at DATETIME NULL COMMENT 'Date du dernier géocodage';

-- Créer un index spatial pour les recherches géographiques
CREATE INDEX idx_prestataire_location ON prestataire(latitude, longitude);

-- =====================================================
-- Table: service_request
-- =====================================================

-- Ajouter les colonnes GPS
ALTER TABLE service_request 
ADD COLUMN latitude DECIMAL(10, 8) NULL COMMENT 'Latitude GPS de l\'adresse',
ADD COLUMN longitude DECIMAL(11, 8) NULL COMMENT 'Longitude GPS de l\'adresse',
ADD COLUMN geocoded_at DATETIME NULL COMMENT 'Date du dernier géocodage';

-- Créer un index spatial pour les recherches géographiques
CREATE INDEX idx_service_request_location ON service_request(latitude, longitude);

-- =====================================================
-- Autres index utiles pour le matching
-- =====================================================

-- Index pour les recherches par statut
CREATE INDEX idx_service_request_status ON service_request(status);

-- Index pour les recherches par catégorie et statut
CREATE INDEX idx_service_request_category_status ON service_request(category_id, status);

-- Index pour les dates préférées
CREATE INDEX idx_service_request_preferred_date ON service_request(preferred_date);

-- Index composite pour le matching prestataire
CREATE INDEX idx_prestataire_approved_active ON prestataire(is_approved, is_active);

-- Index pour le rayon de service
CREATE INDEX idx_prestataire_radius ON prestataire(service_radius);

-- =====================================================
-- Table de cache pour le géocodage (optionnel)
-- =====================================================

CREATE TABLE IF NOT EXISTS geocoding_cache (
    id INT AUTO_INCREMENT PRIMARY KEY,
    address VARCHAR(500) NOT NULL,
    address_hash VARCHAR(32) NOT NULL UNIQUE,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    formatted_address TEXT NULL,
    provider VARCHAR(50) NULL COMMENT 'google, nominatim, etc.',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_geocoding_hash (address_hash),
    INDEX idx_geocoding_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Procédure pour géocoder les adresses existantes
-- =====================================================

-- Note: Cette procédure nécessite l'implémentation d'un service de géocodage
-- Elle devra être appelée via un script PHP/Symfony

-- Pour information, voici la logique à implémenter :
/*
DELIMITER $$

CREATE PROCEDURE geocode_existing_addresses()
BEGIN
    -- Géocoder les prestataires sans coordonnées
    UPDATE prestataire p
    SET 
        p.latitude = (SELECT latitude FROM geocode_address(p.address, p.postal_code, p.city)),
        p.longitude = (SELECT longitude FROM geocode_address(p.address, p.postal_code, p.city)),
        p.geocoded_at = NOW()
    WHERE p.latitude IS NULL 
      AND p.longitude IS NULL
      AND p.address IS NOT NULL;

    -- Géocoder les service_request sans coordonnées
    UPDATE service_request sr
    SET 
        sr.latitude = (SELECT latitude FROM geocode_address(sr.address, sr.postal_code, sr.city)),
        sr.longitude = (SELECT longitude FROM geocode_address(sr.address, sr.postal_code, sr.city)),
        sr.geocoded_at = NOW()
    WHERE sr.latitude IS NULL 
      AND sr.longitude IS NULL
      AND sr.address IS NOT NULL;
END$$

DELIMITER ;
*/

-- =====================================================
-- Données de test (optionnel - pour développement)
-- =====================================================

-- Quelques coordonnées de grandes villes françaises pour les tests
/*
INSERT INTO geocoding_cache (address, address_hash, latitude, longitude, formatted_address, provider) VALUES
('Paris, France', MD5('paris france'), 48.8566, 2.3522, 'Paris, Île-de-France, France', 'manual'),
('Lyon, France', MD5('lyon france'), 45.7640, 4.8357, 'Lyon, Auvergne-Rhône-Alpes, France', 'manual'),
('Marseille, France', MD5('marseille france'), 43.2965, 5.3698, 'Marseille, Provence-Alpes-Côte d\'Azur, France', 'manual'),
('Toulouse, France', MD5('toulouse france'), 43.6047, 1.4442, 'Toulouse, Occitanie, France', 'manual'),
('Nice, France', MD5('nice france'), 43.7102, 7.2620, 'Nice, Provence-Alpes-Côte d\'Azur, France', 'manual'),
('Nantes, France', MD5('nantes france'), 47.2184, -1.5536, 'Nantes, Pays de la Loire, France', 'manual'),
('Strasbourg, France', MD5('strasbourg france'), 48.5734, 7.7521, 'Strasbourg, Grand Est, France', 'manual'),
('Montpellier, France', MD5('montpellier france'), 43.6108, 3.8767, 'Montpellier, Occitanie, France', 'manual'),
('Bordeaux, France', MD5('bordeaux france'), 44.8378, -0.5792, 'Bordeaux, Nouvelle-Aquitaine, France', 'manual'),
('Lille, France', MD5('lille france'), 50.6292, 3.0573, 'Lille, Hauts-de-France, France', 'manual');
*/

-- =====================================================
-- Vues utiles pour le monitoring
-- =====================================================

-- Vue pour voir les prestataires sans géocodage
CREATE OR REPLACE VIEW v_prestataires_not_geocoded AS
SELECT 
    id,
    email,
    first_name,
    last_name,
    address,
    postal_code,
    city,
    created_at
FROM prestataire
WHERE (latitude IS NULL OR longitude IS NULL)
  AND address IS NOT NULL
  AND is_active = 1;

-- Vue pour voir les service_request sans géocodage
CREATE OR REPLACE VIEW v_service_requests_not_geocoded AS
SELECT 
    sr.id,
    sr.address,
    sr.postal_code,
    sr.city,
    sr.status,
    sr.created_at,
    c.email as client_email
FROM service_request sr
INNER JOIN client c ON sr.client_id = c.id
WHERE (sr.latitude IS NULL OR sr.longitude IS NULL)
  AND sr.address IS NOT NULL
  AND sr.status IN ('open', 'quoting');

-- =====================================================
-- Triggers pour mettre à jour geocoded_at
-- =====================================================

-- Trigger pour prestataire
DELIMITER $$

CREATE TRIGGER trg_prestataire_geocoded_update
BEFORE UPDATE ON prestataire
FOR EACH ROW
BEGIN
    IF (NEW.latitude IS NOT NULL AND NEW.longitude IS NOT NULL) 
       AND (OLD.latitude IS NULL OR OLD.longitude IS NULL 
            OR NEW.latitude != OLD.latitude OR NEW.longitude != OLD.longitude) THEN
        SET NEW.geocoded_at = NOW();
    END IF;
END$$

-- Trigger pour service_request
CREATE TRIGGER trg_service_request_geocoded_update
BEFORE UPDATE ON service_request
FOR EACH ROW
BEGIN
    IF (NEW.latitude IS NOT NULL AND NEW.longitude IS NOT NULL) 
       AND (OLD.latitude IS NULL OR OLD.longitude IS NULL 
            OR NEW.latitude != OLD.latitude OR NEW.longitude != OLD.longitude) THEN
        SET NEW.geocoded_at = NOW();
    END IF;
END$$

DELIMITER ;

-- =====================================================
-- Statistiques et monitoring
-- =====================================================

-- Requête pour voir le taux de géocodage
SELECT 
    'Prestataires' as type,
    COUNT(*) as total,
    SUM(CASE WHEN latitude IS NOT NULL AND longitude IS NOT NULL THEN 1 ELSE 0 END) as geocoded,
    ROUND(SUM(CASE WHEN latitude IS NOT NULL AND longitude IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) as geocoding_rate
FROM prestataire
WHERE is_active = 1
UNION ALL
SELECT 
    'Service Requests' as type,
    COUNT(*) as total,
    SUM(CASE WHEN latitude IS NOT NULL AND longitude IS NOT NULL THEN 1 ELSE 0 END) as geocoded,
    ROUND(SUM(CASE WHEN latitude IS NOT NULL AND longitude IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) as geocoding_rate
FROM service_request
WHERE status IN ('open', 'quoting');

-- =====================================================
-- Nettoyage du cache de géocodage (à exécuter périodiquement)
-- =====================================================

-- Supprimer les entrées de cache de plus de 6 mois
-- DELETE FROM geocoding_cache WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH);

-- =====================================================
-- Notes d'implémentation
-- =====================================================

/*
IMPORTANT: Après cette migration, vous devez :

1. Mettre à jour les entités Doctrine :

    // Dans Prestataire.php et ServiceRequest.php
    #[ORM\Column(type: 'decimal', precision: 10, scale: 8, nullable: true)]
    private ?float $latitude = null;

    #[ORM\Column(type: 'decimal', precision: 11, scale: 8, nullable: true)]
    private ?float $longitude = null;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private ?\DateTimeInterface $geocodedAt = null;

2. Créer un service de géocodage :

    // src/Service/Geocoding/GeocodingService.php
    
3. Créer une commande Symfony pour géocoder les adresses existantes :

    // bin/console app:geocode:addresses
    
4. Ajouter un Event Listener pour géocoder automatiquement :

    // Sur les events PrePersist et PreUpdate
    
5. Configurer les credentials API :

    // .env
    GOOGLE_MAPS_API_KEY=your_key_here
    # ou
    NOMINATIM_USER_AGENT=your_app_name

6. Implémenter le cache Redis pour le géocodage :

    // Pour éviter les appels répétés à l'API

PERFORMANCES:
- Les index spatiaux amélioreront les recherches géographiques
- Le cache de géocodage réduira les coûts d'API
- Les triggers maintiendront automatiquement geocoded_at

COÛTS:
- Google Maps Geocoding : ~$5 pour 1000 requêtes (gratuit jusqu'à $200/mois)
- Nominatim : Gratuit mais limité à 1 req/sec
- Recommandation : Utiliser Nominatim + cache + Google Maps en fallback
*/

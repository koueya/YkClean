# 📢 Documentation - Notification des Prestataires Correspondants

## Vue d'ensemble

La méthode `notifyMatchingPrestataires()` du `MatchingService` est responsable de :
1. Trouver les meilleurs prestataires pour une demande de service
2. Les notifier via plusieurs canaux (email, push, in-app)
3. Enregistrer l'historique des notifications
4. Gérer les erreurs et fournir des statistiques détaillées

## 🎯 Flux d'Utilisation

### Création d'une Demande de Service (Client)

```php
// Dans ServiceRequestController (côté client)
public function create(Request $request): JsonResponse
{
    // 1. Créer la demande de service
    $serviceRequest = new ServiceRequest();
    // ... configuration de la demande ...
    
    $this->entityManager->persist($serviceRequest);
    $this->entityManager->flush();
    
    // 2. Notifier les prestataires correspondants
    $notificationResult = $this->matchingService->notifyMatchingPrestataires(
        $serviceRequest,
        [
            'max_prestataires' => 10,  // Nombre max à notifier
            'min_score' => 60,         // Score minimum requis
        ]
    );
    
    return $this->json([
        'success' => true,
        'service_request' => $serviceRequest,
        'notification_result' => $notificationResult,
    ]);
}
```

## 📋 Signature de la Méthode

```php
public function notifyMatchingPrestataires(
    ServiceRequest $serviceRequest,
    array $options = []
): array
```

### Paramètres

#### `$serviceRequest` (ServiceRequest) - **Requis**
La demande de service pour laquelle notifier les prestataires.

#### `$options` (array) - **Optionnel**
Options de configuration :

| Option | Type | Défaut | Description |
|--------|------|--------|-------------|
| `max_prestataires` | int | 10 | Nombre maximum de prestataires à notifier |
| `min_score` | float | 60 | Score minimum de matching requis (0-100) |
| `channels` | array | `['email', 'push', 'in_app']` | Canaux de notification |
| `priority` | string | `'high'` | Priorité de la notification |

### Valeur de Retour

Retourne un tableau associatif avec :

```php
[
    'success' => bool,              // Succès global de l'opération
    'message' => string,            // Message descriptif
    'notified_count' => int,        // Nombre de prestataires notifiés
    'failed_count' => int,          // Nombre d'échecs
    'matches_found' => int,         // Nombre total de correspondances
    'details' => [                  // Détails par prestataire
        123 => [                    // ID du prestataire
            'prestataire_id' => 123,
            'prestataire_name' => 'Jean Dupont',
            'score' => 85.5,
            'notification_sent' => true,
            'notification_results' => [...],
        ],
        // ...
    ]
]
```

## 🔄 Processus Détaillé

### Étape 1 : Recherche de Correspondances

```php
$matches = $this->findMatchingPrestataires($serviceRequest, $maxPrestataires, [
    'min_score' => $minScore,
]);
```

Le système :
- Géocode l'adresse de la demande
- Recherche les prestataires éligibles (catégorie + distance)
- Calcule un score de matching (0-100) basé sur 6 critères
- Filtre par score minimum
- Trie par score décroissant

### Étape 2 : Préparation des Données

Les données suivantes sont préparées pour la notification :

```php
[
    'service_request_id' => 123,
    'category_name' => 'Nettoyage',
    'category_id' => 1,
    'client_name' => 'Marie',           // Prénom uniquement
    'address' => 'Rue de la Paix',      // Sans numéro de rue
    'city' => 'Paris',
    'postal_code' => '75001',
    'description' => 'Description...',
    'preferred_date' => DateTime,
    'alternative_dates' => [...],
    'duration_estimated' => 120,        // minutes
    'budget' => 50.00,
    'frequency' => 'ponctuel',
    'total_matches' => 10,
    'matching_score' => 85.5,           // Ajouté pour chaque prestataire
    'score_details' => [...],           // Détails du scoring
    'distance_km' => 5.2,               // Distance calculée
]
```

### Étape 3 : Envoi des Notifications

Pour chaque prestataire :

```php
$this->notificationService->notifyNewServiceRequest(
    $serviceRequest,
    [$prestataire]
);
```

Notifications envoyées :
- **Email** : Détails complets de la demande + lien pour créer un devis
- **Push** : Notification mobile "Nouvelle demande dans votre zone"
- **In-App** : Notification dans l'interface prestataire

### Étape 4 : Enregistrement de l'Historique

```php
$this->recordNotification($serviceRequest, $prestataire, $matchingScore);
```

Enregistre :
- Date/heure de notification
- Score de matching
- Prestataire notifié
- Service request associé

### Étape 5 : Mise à Jour du Statut

Si au moins un prestataire a été notifié :

```php
$serviceRequest->setStatus('notified');
$serviceRequest->setNotifiedAt(new \DateTimeImmutable());
```

## 📊 Exemples d'Utilisation

### Exemple 1 : Notification Standard

```php
// Notification avec paramètres par défaut
$result = $this->matchingService->notifyMatchingPrestataires($serviceRequest);

if ($result['success']) {
    echo "✅ {$result['notified_count']} prestataires notifiés";
} else {
    echo "❌ Erreur : {$result['message']}";
}
```

### Exemple 2 : Notification Urgente

```php
// Demande urgente : plus de prestataires, score minimum plus bas
$result = $this->matchingService->notifyMatchingPrestataires(
    $serviceRequest,
    [
        'max_prestataires' => 20,
        'min_score' => 50,
        'priority' => 'urgent',
    ]
);
```

### Exemple 3 : Notification Sélective

```php
// Notifier uniquement les prestataires très bien notés
$result = $this->matchingService->notifyMatchingPrestataires(
    $serviceRequest,
    [
        'max_prestataires' => 5,
        'min_score' => 80,  // Score élevé
        'channels' => ['email', 'push'],  // Pas de notification in-app
    ]
);
```

### Exemple 4 : Re-notification

```php
// Aucun devis reçu après 24h ? Re-notifier avec critères assouplis
$result = $this->matchingService->renotifyPrestataires(
    $serviceRequest,
    [
        'lower_threshold' => true,      // Baisser le score minimum
        'exclude_notified' => true,     // Exclure déjà notifiés
        'max_prestataires' => 15,
    ]
);
```

## 🔒 Confidentialité et Sécurité

### Données Masquées

Pour protéger la vie privée du client :

1. **Nom du client** : Seul le prénom est partagé
2. **Adresse** : Le numéro de rue est supprimé
   - Avant : "123 Rue de la Paix"
   - Après : "Rue de la Paix"
3. **Contact** : Email et téléphone ne sont PAS partagés initialement

### Révélation Progressive

Les informations complètes sont révélées progressivement :

1. **Notification initiale** : Informations minimales
2. **Après acceptation du devis** : Adresse complète
3. **Après confirmation** : Contact direct du client

## 🎨 Personnalisation des Notifications

### Templates Email

Les emails utilisent les templates Twig :

```twig
{# templates/emails/new_service_request.html.twig #}

<h1>Nouvelle Demande de Service</h1>

<p>Bonjour {{ prestataire.firstName }},</p>

<p>Une nouvelle demande de <strong>{{ serviceRequest.category.name }}</strong> 
   correspond à votre profil !</p>

<div class="matching-info">
    <span class="badge">Score de correspondance : {{ matching_score }}/100</span>
    <span class="badge">Distance : {{ distance_km }} km</span>
</div>

<h2>Détails de la demande</h2>
<ul>
    <li><strong>Ville :</strong> {{ serviceRequest.city }}</li>
    <li><strong>Date souhaitée :</strong> {{ serviceRequest.preferredDate|date('d/m/Y') }}</li>
    <li><strong>Durée estimée :</strong> {{ serviceRequest.duration }} min</li>
    <li><strong>Budget :</strong> {{ serviceRequest.budget }}€</li>
</ul>

<a href="{{ url('prestataire_quote_create', {id: serviceRequest.id}) }}" 
   class="btn btn-primary">
    Créer un Devis
</a>
```

### Notifications Push

```php
// Format de la notification push
[
    'title' => 'Nouvelle Demande de Service',
    'body' => 'Nettoyage à Paris (75001) - Score : 85/100',
    'data' => [
        'type' => 'service_request',
        'service_request_id' => 123,
        'score' => 85,
        'action' => 'view_request',
    ],
    'badge' => 1,
    'sound' => 'default',
]
```

## 📈 Métriques et Analytics

### Tracking des Notifications

```php
// Obtenir les statistiques de notification
$stats = $this->matchingService->getNotificationStats($serviceRequest);

// Résultat :
[
    'service_request_id' => 123,
    'potential_matches' => 15,
    'quotes_received' => 7,
    'response_rate' => 46.67,  // 7/15 = 46.67%
    'status' => 'notified',
    'notified_at' => DateTime,
]
```

### KPIs Importants

- **Taux de réponse** : (Devis reçus / Prestataires notifiés) × 100
- **Délai moyen de réponse** : Temps entre notification et premier devis
- **Score moyen des répondants** : Score de matching moyen des prestataires ayant répondu
- **Taux de conversion** : (Devis acceptés / Devis reçus) × 100

## 🔧 Méthodes Complémentaires

### `renotifyPrestataires()`

Re-notifie les prestataires si aucun devis n'a été reçu.

```php
public function renotifyPrestataires(
    ServiceRequest $serviceRequest,
    array $options = []
): array
```

**Utilisation :**
```php
// Commande Cron : toutes les 6h, vérifier les demandes sans réponse
$pendingRequests = $serviceRequestRepository->findPendingWithoutQuotes();

foreach ($pendingRequests as $request) {
    if ($request->getNotifiedAt() < new DateTime('-6 hours')) {
        $this->matchingService->renotifyPrestataires($request);
    }
}
```

### `notifySpecificPrestataire()`

Notifie un prestataire spécifique (invitation manuelle).

```php
public function notifySpecificPrestataire(
    ServiceRequest $serviceRequest,
    Prestataire $prestataire
): array
```

**Utilisation :**
```php
// Admin ou client peut inviter un prestataire spécifique
$result = $this->matchingService->notifySpecificPrestataire(
    $serviceRequest,
    $favoritePrestataire
);
```

## 🚨 Gestion des Erreurs

### Cas d'Erreur Courants

1. **Aucun prestataire trouvé**
```php
[
    'success' => false,
    'message' => 'Aucun prestataire correspondant trouvé',
    'notified_count' => 0,
    'matches_found' => 0,
]
```

2. **Échec de géocodage**
```php
[
    'success' => false,
    'message' => 'Erreur lors de la notification des prestataires',
    'error' => 'Failed to geocode address',
]
```

3. **Échec partiel**
```php
[
    'success' => true,
    'notified_count' => 8,
    'failed_count' => 2,
    'details' => [
        // Prestataires en échec avec les erreurs
    ]
]
```

### Logging

Tous les événements sont loggés :

```php
// Succès
[INFO] Starting prestataire notification process
[INFO] Prestataire notified successfully {prestataire_id: 123, score: 85}
[INFO] Notification process completed {notified_count: 10}

// Erreurs
[ERROR] Failed to notify prestataire {prestataire_id: 456, error: "..."}
[ERROR] Notification process failed {error: "..."}

// Avertissements
[WARNING] No matching prestataires found {service_request_id: 789}
```

## 🎛️ Configuration Avancée

### Ajustement des Seuils

Dans votre configuration :

```yaml
# config/packages/matching.yaml
parameters:
    matching.notification:
        default_max_prestataires: 10
        default_min_score: 60
        urgent_min_score: 50
        urgent_max_prestataires: 20
        renotify_after_hours: 6
        max_renotifications: 3
```

### Règles Métier Personnalisées

Vous pouvez étendre la logique :

```php
class CustomMatchingService extends MatchingService
{
    public function notifyMatchingPrestataires(
        ServiceRequest $serviceRequest,
        array $options = []
    ): array {
        // Règle personnalisée : demandes urgentes
        if ($serviceRequest->isUrgent()) {
            $options['max_prestataires'] = 20;
            $options['min_score'] = 50;
            $options['priority'] = 'urgent';
        }
        
        // Règle personnalisée : client premium
        if ($serviceRequest->getClient()->isPremium()) {
            $options['max_prestataires'] = 15;
            // Notifier les meilleurs prestataires uniquement
        }
        
        return parent::notifyMatchingPrestataires($serviceRequest, $options);
    }
}
```

## 📝 TODO / Améliorations Futures

### Court Terme
- [ ] Créer l'entité `NotificationHistory` pour tracking complet
- [ ] Ajouter méthode pour exclure les prestataires déjà notifiés
- [ ] Implémenter le système de préférences de notification
- [ ] Ajouter A/B testing des messages de notification

### Moyen Terme
- [ ] ML pour optimiser le score minimum selon le taux de réponse
- [ ] Notification progressive (top 3, puis top 10, puis tous)
- [ ] Système de quotas (max X notifications par prestataire par jour)
- [ ] Analytics dashboard pour les performances de notification

### Long Terme
- [ ] Personnalisation des messages par catégorie de service
- [ ] Système de réputation pour les prestataires réactifs
- [ ] Notification géolocalisée en temps réel
- [ ] Integration avec calendrier prestataire

## 🧪 Tests

### Test Unitaire

```php
public function testNotifyMatchingPrestataires()
{
    $serviceRequest = $this->createServiceRequest();
    $prestataires = $this->createPrestataires(10);
    
    $result = $this->matchingService->notifyMatchingPrestataires($serviceRequest);
    
    $this->assertTrue($result['success']);
    $this->assertGreaterThan(0, $result['notified_count']);
    $this->assertEquals('notified', $serviceRequest->getStatus());
}
```

### Test d'Intégration

```php
public function testNotificationEndToEnd()
{
    // 1. Créer une demande
    $response = $this->client->post('/api/client/service-requests', [
        'category_id' => 1,
        'address' => '10 Rue de Rivoli, 75001 Paris',
        // ...
    ]);
    
    $serviceRequestId = $response->json()['id'];
    
    // 2. Vérifier que les prestataires ont reçu des notifications
    $notifications = $this->notificationRepository->findBy([
        'type' => 'service_request_new',
    ]);
    
    $this->assertGreaterThan(0, count($notifications));
    
    // 3. Vérifier les emails en queue
    $this->assertEmailQueued([
        'to' => 'prestataire@example.com',
        'subject' => 'Nouvelle Demande de Service',
    ]);
}
```

## 📚 Ressources

- [NotificationService Documentation](./NotificationService.md)
- [MatchingService Documentation](./MATCHING_SERVICE_README.md)
- [Guide d'Installation](./INSTALLATION_GUIDE.md)

---

**Version:** 1.0.0  
**Dernière mise à jour:** 2025-01-31

<?php

namespace App\Repository\Notification;

use App\Entity\Notification\NotificationHistory;
use App\Entity\Service\ServiceRequest;
use App\Entity\User\Prestataire;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * Repository pour NotificationHistory
 */
class NotificationHistoryRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, NotificationHistory::class);
    }

    /**
     * Trouve l'historique de notifications pour une demande de service
     * 
     * @param ServiceRequest $serviceRequest
     * @return array
     */
    public function findByServiceRequest(ServiceRequest $serviceRequest): array
    {
        return $this->createQueryBuilder('nh')
            ->where('nh.serviceRequest = :serviceRequest')
            ->setParameter('serviceRequest', $serviceRequest)
            ->orderBy('nh.notifiedAt', 'DESC')
            ->getQuery()
            ->getResult();
    }

    /**
     * Trouve l'historique de notifications pour un prestataire
     * 
     * @param Prestataire $prestataire
     * @param int|null $limit
     * @return array
     */
    public function findByPrestataire(Prestataire $prestataire, ?int $limit = null): array
    {
        $qb = $this->createQueryBuilder('nh')
            ->where('nh.prestataire = :prestataire')
            ->setParameter('prestataire', $prestataire)
            ->orderBy('nh.notifiedAt', 'DESC');

        if ($limit) {
            $qb->setMaxResults($limit);
        }

        return $qb->getQuery()->getResult();
    }

    /**
     * Vérifie si un prestataire a déjà été notifié pour une demande
     * 
     * @param ServiceRequest $serviceRequest
     * @param Prestataire $prestataire
     * @return bool
     */
    public function hasBeenNotified(
        ServiceRequest $serviceRequest,
        Prestataire $prestataire
    ): bool {
        $count = $this->createQueryBuilder('nh')
            ->select('COUNT(nh.id)')
            ->where('nh.serviceRequest = :serviceRequest')
            ->andWhere('nh.prestataire = :prestataire')
            ->setParameter('serviceRequest', $serviceRequest)
            ->setParameter('prestataire', $prestataire)
            ->getQuery()
            ->getSingleScalarResult();

        return $count > 0;
    }

    /**
     * Compte le nombre de notifications pour une demande
     * 
     * @param ServiceRequest $serviceRequest
     * @return int
     */
    public function countByServiceRequest(ServiceRequest $serviceRequest): int
    {
        return $this->createQueryBuilder('nh')
            ->select('COUNT(nh.id)')
            ->where('nh.serviceRequest = :serviceRequest')
            ->setParameter('serviceRequest', $serviceRequest)
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * Obtient les statistiques de réponse pour une demande
     * 
     * @param ServiceRequest $serviceRequest
     * @return array
     */
    public function getResponseStats(ServiceRequest $serviceRequest): array
    {
        $notifications = $this->findByServiceRequest($serviceRequest);

        $total = count($notifications);
        $viewed = 0;
        $quoted = 0;
        $ignored = 0;
        $totalResponseTime = 0;
        $fastResponses = 0;

        foreach ($notifications as $notification) {
            if ($notification->wasViewed()) {
                $viewed++;
            }
            if ($notification->hasQuoted()) {
                $quoted++;
            }
            if ($notification->getResponseStatus() === 'ignored') {
                $ignored++;
            }
            if ($notification->getResponseTimeMinutes()) {
                $totalResponseTime += $notification->getResponseTimeMinutes();
            }
            if ($notification->isFastResponse()) {
                $fastResponses++;
            }
        }

        return [
            'total_notified' => $total,
            'viewed_count' => $viewed,
            'viewed_rate' => $total > 0 ? round(($viewed / $total) * 100, 2) : 0,
            'quoted_count' => $quoted,
            'quote_rate' => $total > 0 ? round(($quoted / $total) * 100, 2) : 0,
            'ignored_count' => $ignored,
            'ignored_rate' => $total > 0 ? round(($ignored / $total) * 100, 2) : 0,
            'avg_response_time_minutes' => $quoted > 0 ? round($totalResponseTime / $quoted) : null,
            'fast_responses' => $fastResponses,
            'fast_response_rate' => $quoted > 0 ? round(($fastResponses / $quoted) * 100, 2) : 0,
        ];
    }

    /**
     * Obtient les statistiques de performance pour un prestataire
     * 
     * @param Prestataire $prestataire
     * @return array
     */
    public function getPrestataireStats(Prestataire $prestataire): array
    {
        $notifications = $this->findByPrestataire($prestataire);

        $total = count($notifications);
        $viewed = 0;
        $quoted = 0;
        $totalResponseTime = 0;
        $responseCount = 0;

        foreach ($notifications as $notification) {
            if ($notification->wasViewed()) {
                $viewed++;
            }
            if ($notification->hasQuoted()) {
                $quoted++;
                if ($notification->getResponseTimeMinutes()) {
                    $totalResponseTime += $notification->getResponseTimeMinutes();
                    $responseCount++;
                }
            }
        }

        return [
            'total_notifications' => $total,
            'view_rate' => $total > 0 ? round(($viewed / $total) * 100, 2) : 0,
            'quote_rate' => $total > 0 ? round(($quoted / $total) * 100, 2) : 0,
            'avg_response_time_hours' => $responseCount > 0 
                ? round(($totalResponseTime / $responseCount) / 60, 1) 
                : null,
        ];
    }

    /**
     * Trouve les prestataires déjà notifiés pour une demande
     * 
     * @param ServiceRequest $serviceRequest
     * @return array Array de Prestataire
     */
    public function findNotifiedPrestataires(ServiceRequest $serviceRequest): array
    {
        $result = $this->createQueryBuilder('nh')
            ->select('IDENTITY(nh.prestataire)')
            ->where('nh.serviceRequest = :serviceRequest')
            ->setParameter('serviceRequest', $serviceRequest)
            ->getQuery()
            ->getScalarResult();

        return array_column($result, 1);
    }

    /**
     * Trouve les notifications sans réponse après X heures
     * 
     * @param int $hoursAgo
     * @return array
     */
    public function findUnrespondedAfter(int $hoursAgo): array
    {
        $cutoffDate = new \DateTime("-{$hoursAgo} hours");

        return $this->createQueryBuilder('nh')
            ->where('nh.notifiedAt < :cutoffDate')
            ->andWhere('nh.wasViewed = :notViewed')
            ->andWhere('nh.hasQuoted = :notQuoted')
            ->setParameter('cutoffDate', $cutoffDate)
            ->setParameter('notViewed', false)
            ->setParameter('notQuoted', false)
            ->getQuery()
            ->getResult();
    }

    /**
     * Trouve les meilleures correspondances (score élevé + devis soumis)
     * 
     * @param int $limit
     * @return array
     */
    public function findBestMatches(int $limit = 100): array
    {
        return $this->createQueryBuilder('nh')
            ->where('nh.hasQuoted = :hasQuoted')
            ->andWhere('nh.matchingScore >= :minScore')
            ->setParameter('hasQuoted', true)
            ->setParameter('minScore', 70)
            ->orderBy('nh.matchingScore', 'DESC')
            ->addOrderBy('nh.responseTimeMinutes', 'ASC')
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }

    /**
     * Calcule le score de réactivité moyen par catégorie
     * 
     * @return array
     */
    public function getAverageResponseTimeByCategory(): array
    {
        return $this->createQueryBuilder('nh')
            ->select('cat.id as category_id, cat.name as category_name, AVG(nh.responseTimeMinutes) as avg_response_time')
            ->leftJoin('nh.serviceRequest', 'sr')
            ->leftJoin('sr.category', 'cat')
            ->where('nh.hasQuoted = :hasQuoted')
            ->andWhere('nh.responseTimeMinutes IS NOT NULL')
            ->setParameter('hasQuoted', true)
            ->groupBy('cat.id, cat.name')
            ->orderBy('avg_response_time', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * Trouve les top prestataires par taux de réponse
     * 
     * @param int $minNotifications Nombre minimum de notifications reçues
     * @param int $limit
     * @return array
     */
    public function findTopResponders(int $minNotifications = 10, int $limit = 20): array
    {
        return $this->createQueryBuilder('nh')
            ->select('p.id, p.firstName, p.lastName, p.email, 
                     COUNT(nh.id) as total_notifications,
                     SUM(CASE WHEN nh.hasQuoted = true THEN 1 ELSE 0 END) as quotes_count,
                     (SUM(CASE WHEN nh.hasQuoted = true THEN 1 ELSE 0 END) * 100.0 / COUNT(nh.id)) as quote_rate,
                     AVG(nh.responseTimeMinutes) as avg_response_time')
            ->leftJoin('nh.prestataire', 'p')
            ->groupBy('p.id, p.firstName, p.lastName, p.email')
            ->having('COUNT(nh.id) >= :minNotifications')
            ->setParameter('minNotifications', $minNotifications)
            ->orderBy('quote_rate', 'DESC')
            ->addOrderBy('avg_response_time', 'ASC')
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }

    /**
     * Marque les notifications expirées comme "expired"
     * 
     * @param \DateTime $expirationDate
     * @return int Nombre de notifications mises à jour
     */
    public function markExpired(\DateTime $expirationDate): int
    {
        return $this->createQueryBuilder('nh')
            ->update()
            ->set('nh.responseStatus', ':status')
            ->where('nh.notifiedAt < :expirationDate')
            ->andWhere('nh.hasQuoted = :notQuoted')
            ->andWhere('nh.responseStatus IS NULL')
            ->setParameter('status', 'expired')
            ->setParameter('expirationDate', $expirationDate)
            ->setParameter('notQuoted', false)
            ->getQuery()
            ->execute();
    }

    /**
     * Supprime les anciens historiques (plus de X jours)
     * 
     * @param int $daysToKeep
     * @return int Nombre d'enregistrements supprimés
     */
    public function deleteOlderThan(int $daysToKeep = 365): int
    {
        $cutoffDate = new \DateTime("-{$daysToKeep} days");

        return $this->createQueryBuilder('nh')
            ->delete()
            ->where('nh.notifiedAt < :cutoffDate')
            ->setParameter('cutoffDate', $cutoffDate)
            ->getQuery()
            ->execute();
    }
}

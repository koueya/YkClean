-- Migration : Ajout de la table notification_history pour le tracking des notifications
-- Date : 2025-01-31
-- Description : Permet de tracker et analyser les notifications envoyées aux prestataires

-- =====================================================
-- Table: notification_history
-- =====================================================

CREATE TABLE IF NOT EXISTS notification_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    
    -- Relations
    service_request_id INT NOT NULL,
    prestataire_id INT NOT NULL,
    
    -- Données de matching
    matching_score DECIMAL(5, 2) NOT NULL COMMENT 'Score de correspondance (0-100)',
    score_details JSON NULL COMMENT 'Détails du scoring (distance, disponibilité, etc.)',
    distance DECIMAL(8, 2) NULL COMMENT 'Distance en kilomètres',
    
    -- Configuration de la notification
    channels JSON NOT NULL COMMENT 'Canaux utilisés (email, push, sms)',
    priority VARCHAR(20) NOT NULL DEFAULT 'medium' COMMENT 'Priorité (low, medium, high, urgent)',
    
    -- Dates
    notified_at DATETIME NOT NULL COMMENT 'Date d\'envoi de la notification',
    viewed_at DATETIME NULL COMMENT 'Date de consultation',
    quoted_at DATETIME NULL COMMENT 'Date de soumission du devis',
    
    -- Statut de réponse
    was_viewed BOOLEAN NOT NULL DEFAULT FALSE COMMENT 'A été consultée',
    has_quoted BOOLEAN NOT NULL DEFAULT FALSE COMMENT 'A soumis un devis',
    response_status VARCHAR(50) NULL COMMENT 'Statut: viewed, quoted, ignored, expired',
    response_time_minutes INT NULL COMMENT 'Temps de réponse en minutes',
    
    -- Résultats de notification
    notification_results JSON NULL COMMENT 'Résultats détaillés de l\'envoi',
    
    -- Re-notification
    is_renotification BOOLEAN NOT NULL DEFAULT FALSE COMMENT 'Est une re-notification',
    notification_attempt INT NOT NULL DEFAULT 1 COMMENT 'Numéro de tentative',
    
    -- Contraintes
    CONSTRAINT fk_nh_service_request 
        FOREIGN KEY (service_request_id) 
        REFERENCES service_request(id) 
        ON DELETE CASCADE,
    
    CONSTRAINT fk_nh_prestataire 
        FOREIGN KEY (prestataire_id) 
        REFERENCES prestataire(id) 
        ON DELETE CASCADE,
    
    -- Index pour les performances
    INDEX idx_service_request (service_request_id),
    INDEX idx_prestataire (prestataire_id),
    INDEX idx_notified_at (notified_at),
    INDEX idx_response_status (response_status),
    INDEX idx_matching_score (matching_score),
    INDEX idx_has_quoted (has_quoted),
    
    -- Index composite pour les requêtes fréquentes
    INDEX idx_sr_prestataire (service_request_id, prestataire_id),
    INDEX idx_prestataire_quoted (prestataire_id, has_quoted, quoted_at),
    INDEX idx_sr_status (service_request_id, response_status),
    
    -- Contrainte unique : un prestataire ne peut être notifié qu'une fois par demande (sauf re-notification)
    UNIQUE KEY uk_notification (service_request_id, prestataire_id, notification_attempt)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Ajout de colonnes à service_request
-- =====================================================

-- Ajouter les colonnes pour tracker l'état des notifications
ALTER TABLE service_request 
ADD COLUMN notified_at DATETIME NULL COMMENT 'Date de notification des prestataires' AFTER status,
ADD COLUMN notified_count INT DEFAULT 0 COMMENT 'Nombre de prestataires notifiés' AFTER notified_at,
ADD COLUMN quotes_received_count INT DEFAULT 0 COMMENT 'Nombre de devis reçus' AFTER notified_count;

-- Index pour les recherches
CREATE INDEX idx_sr_notified_at ON service_request(notified_at);

-- =====================================================
-- Triggers pour mettre à jour automatiquement les compteurs
-- =====================================================

DELIMITER $$

-- Trigger 1: Incrémenter notified_count quand une notification est envoyée
CREATE TRIGGER trg_nh_after_insert
AFTER INSERT ON notification_history
FOR EACH ROW
BEGIN
    UPDATE service_request 
    SET notified_count = (
        SELECT COUNT(*) 
        FROM notification_history 
        WHERE service_request_id = NEW.service_request_id
    )
    WHERE id = NEW.service_request_id;
END$$

-- Trigger 2: Mettre à jour quotes_received_count quand un devis est soumis
CREATE TRIGGER trg_nh_after_update_quoted
AFTER UPDATE ON notification_history
FOR EACH ROW
BEGIN
    -- Si has_quoted passe de FALSE à TRUE
    IF NEW.has_quoted = TRUE AND OLD.has_quoted = FALSE THEN
        UPDATE service_request 
        SET quotes_received_count = quotes_received_count + 1
        WHERE id = NEW.service_request_id;
    END IF;
END$$

DELIMITER ;

-- =====================================================
-- Vues utiles pour l'analyse
-- =====================================================

-- Vue 1: Statistiques de réponse par demande de service
CREATE OR REPLACE VIEW v_service_request_notification_stats AS
SELECT 
    sr.id as service_request_id,
    sr.status,
    sr.category_id,
    sr.created_at,
    sr.notified_at,
    COUNT(nh.id) as total_notified,
    SUM(CASE WHEN nh.was_viewed = 1 THEN 1 ELSE 0 END) as viewed_count,
    SUM(CASE WHEN nh.has_quoted = 1 THEN 1 ELSE 0 END) as quoted_count,
    ROUND(AVG(CASE WHEN nh.has_quoted = 1 THEN nh.response_time_minutes ELSE NULL END)) as avg_response_time_min,
    ROUND(AVG(nh.matching_score), 2) as avg_matching_score,
    MAX(nh.matching_score) as max_matching_score,
    ROUND(
        (SUM(CASE WHEN nh.has_quoted = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(nh.id)), 
        2
    ) as quote_rate_percent
FROM service_request sr
LEFT JOIN notification_history nh ON sr.id = nh.service_request_id
GROUP BY sr.id, sr.status, sr.category_id, sr.created_at, sr.notified_at;

-- Vue 2: Performance des prestataires
CREATE OR REPLACE VIEW v_prestataire_notification_performance AS
SELECT 
    p.id as prestataire_id,
    p.email,
    p.first_name,
    p.last_name,
    COUNT(nh.id) as total_notifications,
    SUM(CASE WHEN nh.was_viewed = 1 THEN 1 ELSE 0 END) as viewed_count,
    SUM(CASE WHEN nh.has_quoted = 1 THEN 1 ELSE 0 END) as quoted_count,
    ROUND(
        (SUM(CASE WHEN nh.was_viewed = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(nh.id)), 
        2
    ) as view_rate_percent,
    ROUND(
        (SUM(CASE WHEN nh.has_quoted = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(nh.id)), 
        2
    ) as quote_rate_percent,
    ROUND(AVG(CASE WHEN nh.has_quoted = 1 THEN nh.response_time_minutes ELSE NULL END)) as avg_response_time_min,
    ROUND(AVG(nh.matching_score), 2) as avg_matching_score
FROM prestataire p
LEFT JOIN notification_history nh ON p.id = nh.prestataire_id
GROUP BY p.id, p.email, p.first_name, p.last_name
HAVING total_notifications > 0
ORDER BY quote_rate_percent DESC;

-- Vue 3: Notifications en attente de réponse (> 24h)
CREATE OR REPLACE VIEW v_pending_notifications AS
SELECT 
    nh.id,
    nh.service_request_id,
    sr.category_id,
    nh.prestataire_id,
    p.email as prestataire_email,
    p.first_name,
    p.last_name,
    nh.matching_score,
    nh.notified_at,
    TIMESTAMPDIFF(HOUR, nh.notified_at, NOW()) as hours_since_notification,
    nh.was_viewed,
    nh.has_quoted,
    nh.response_status
FROM notification_history nh
INNER JOIN service_request sr ON nh.service_request_id = sr.id
INNER JOIN prestataire p ON nh.prestataire_id = p.id
WHERE nh.has_quoted = 0
  AND nh.notified_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)
  AND sr.status IN ('open', 'notified', 'quoting')
ORDER BY nh.notified_at ASC;

-- =====================================================
-- Procédures stockées utiles
-- =====================================================

DELIMITER $$

-- Procédure 1: Marquer les notifications expirées
CREATE PROCEDURE sp_mark_expired_notifications(IN days_old INT)
BEGIN
    UPDATE notification_history
    SET response_status = 'expired'
    WHERE notified_at < DATE_SUB(NOW(), INTERVAL days_old DAY)
      AND has_quoted = 0
      AND (response_status IS NULL OR response_status = 'viewed');
    
    SELECT ROW_COUNT() as updated_count;
END$$

-- Procédure 2: Obtenir les top prestataires réactifs
CREATE PROCEDURE sp_get_top_responsive_prestataires(IN min_notifications INT, IN result_limit INT)
BEGIN
    SELECT 
        p.id,
        p.email,
        p.first_name,
        p.last_name,
        COUNT(nh.id) as total_notifications,
        SUM(CASE WHEN nh.has_quoted = 1 THEN 1 ELSE 0 END) as quotes_submitted,
        ROUND(
            (SUM(CASE WHEN nh.has_quoted = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(nh.id)), 
            2
        ) as quote_rate,
        ROUND(
            AVG(CASE WHEN nh.has_quoted = 1 THEN nh.response_time_minutes ELSE NULL END) / 60, 
            1
        ) as avg_response_hours
    FROM prestataire p
    INNER JOIN notification_history nh ON p.id = nh.prestataire_id
    WHERE p.is_active = 1
      AND p.is_approved = 1
    GROUP BY p.id, p.email, p.first_name, p.last_name
    HAVING total_notifications >= min_notifications
    ORDER BY quote_rate DESC, avg_response_hours ASC
    LIMIT result_limit;
END$$

-- Procédure 3: Obtenir les statistiques de notification par catégorie
CREATE PROCEDURE sp_get_notification_stats_by_category()
BEGIN
    SELECT 
        cat.id as category_id,
        cat.name as category_name,
        COUNT(DISTINCT nh.service_request_id) as service_requests_count,
        COUNT(nh.id) as total_notifications,
        SUM(CASE WHEN nh.has_quoted = 1 THEN 1 ELSE 0 END) as total_quotes,
        ROUND(
            AVG(CASE WHEN nh.has_quoted = 1 THEN nh.response_time_minutes ELSE NULL END) / 60, 
            1
        ) as avg_response_hours,
        ROUND(
            (SUM(CASE WHEN nh.has_quoted = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(nh.id)), 
            2
        ) as quote_rate
    FROM service_category cat
    INNER JOIN service_request sr ON cat.id = sr.category_id
    INNER JOIN notification_history nh ON sr.id = nh.service_request_id
    GROUP BY cat.id, cat.name
    ORDER BY total_notifications DESC;
END$$

DELIMITER ;

-- =====================================================
-- Données de test (optionnel)
-- =====================================================

/*
-- Exemple d'insertion de données de test
INSERT INTO notification_history 
    (service_request_id, prestataire_id, matching_score, score_details, distance, 
     channels, priority, notified_at, was_viewed, has_quoted, response_status)
VALUES
    (1, 1, 85.50, 
     '{"distance": 90, "availability": 100, "rating": 80, "experience": 70, "price": 85, "response_rate": 75}',
     3.5, 
     '["email", "push", "in_app"]', 
     'high', 
     NOW(), 
     1, 
     1, 
     'quoted');
*/

-- =====================================================
-- Index de performance additionnels (optionnel)
-- =====================================================

-- Pour les requêtes analytiques
CREATE INDEX idx_nh_analytics ON notification_history(
    has_quoted, 
    response_time_minutes, 
    matching_score
);

-- Pour les recherches par période
CREATE INDEX idx_nh_date_range ON notification_history(
    notified_at, 
    response_status
);

-- =====================================================
-- Événements planifiés (optionnel)
-- =====================================================

-- Événement 1: Marquer les notifications expirées tous les jours à minuit
/*
CREATE EVENT IF NOT EXISTS evt_mark_expired_notifications
ON SCHEDULE EVERY 1 DAY
STARTS (TIMESTAMP(CURRENT_DATE) + INTERVAL 1 DAY)
DO
    CALL sp_mark_expired_notifications(7);
*/

-- Événement 2: Nettoyer les vieilles données tous les mois
/*
CREATE EVENT IF NOT EXISTS evt_cleanup_old_notifications
ON SCHEDULE EVERY 1 MONTH
STARTS (TIMESTAMP(CURRENT_DATE) + INTERVAL 1 MONTH)
DO
    DELETE FROM notification_history 
    WHERE notified_at < DATE_SUB(NOW(), INTERVAL 365 DAY);
*/

-- =====================================================
-- Notes d'implémentation
-- =====================================================

/*
APRÈS CETTE MIGRATION:

1. Mettre à jour le MatchingService pour utiliser NotificationHistory:
   - Dans recordNotification(), créer une entrée NotificationHistory
   - Dans renotifyPrestataires(), exclure les prestataires déjà notifiés
   - Dans getNotificationStats(), utiliser les données de la table

2. Créer des listeners Doctrine pour mettre à jour automatiquement:
   - wasViewed quand le prestataire consulte la demande
   - hasQuoted et quotedAt quand un devis est soumis

3. Créer une commande Symfony pour marquer les expirations:
   php bin/console app:notifications:mark-expired

4. Ajouter un dashboard analytics:
   - Taux de réponse par catégorie
   - Top prestataires réactifs
   - Temps de réponse moyen
   - Notifications en attente

5. Monitorer les performances:
   - Vérifier les index utilisés
   - Optimiser les requêtes lentes
   - Mettre en cache les stats fréquentes

EXEMPLES DE REQUÊTES UTILES:

-- Taux de réponse global
SELECT 
    COUNT(*) as total,
    SUM(has_quoted) as quoted,
    ROUND(SUM(has_quoted) * 100.0 / COUNT(*), 2) as rate
FROM notification_history;

-- Prestataires les plus réactifs
SELECT * FROM v_prestataire_notification_performance
WHERE total_notifications >= 10
ORDER BY quote_rate_percent DESC
LIMIT 20;

-- Demandes avec peu de réponses
SELECT * FROM v_service_request_notification_stats
WHERE total_notified >= 5 
  AND quoted_count < 2
ORDER BY created_at DESC;
*/
